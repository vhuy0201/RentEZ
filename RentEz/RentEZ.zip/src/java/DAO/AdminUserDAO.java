package DAO;

import Connection.DBConnection;
import Model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdminUserDAO {
    
    public List<User> getFilteredUsers(String search, String roleFilter, String statusFilter, int page, int pageSize) {
        List<User> users = new ArrayList<>();
        Connection conn = DBConnection.getConnection();
        
        StringBuilder sql = new StringBuilder("SELECT * FROM [User] WHERE 1=1");
        
        if (search != null && !search.trim().isEmpty()) {
            sql.append(" AND (Name LIKE ? OR Email LIKE ? OR Phone LIKE ?)");
        }
        if (roleFilter != null && !roleFilter.trim().isEmpty()) {
            sql.append(" AND Role = ?");
        }
        
        sql.append(" ORDER BY UserID DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY");
        
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql.toString());
            int paramIndex = 1;
            
            if (search != null && !search.trim().isEmpty()) {
                String searchPattern = "%" + search + "%";
                pstmt.setString(paramIndex++, searchPattern);
                pstmt.setString(paramIndex++, searchPattern);
                pstmt.setString(paramIndex++, searchPattern);
            }
            if (roleFilter != null && !roleFilter.trim().isEmpty()) {
                pstmt.setString(paramIndex++, roleFilter);
            }
            
            pstmt.setInt(paramIndex++, (page - 1) * pageSize);
            pstmt.setInt(paramIndex, pageSize);
            
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("UserID"));
                user.setName(rs.getString("Name"));
                user.setEmail(rs.getString("Email"));
                user.setPhone(rs.getString("Phone"));
                user.setAddress(rs.getString("Address"));
                user.setRole(rs.getString("Role"));
                user.setAvatar(rs.getString("Avatar"));
                users.add(user);
            }
            
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return users;
    }
    
    public int getTotalFilteredUsers(String search, String roleFilter, String statusFilter) {
        Connection conn = DBConnection.getConnection();
        
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM [User] WHERE 1=1");
        
        if (search != null && !search.trim().isEmpty()) {
            sql.append(" AND (Name LIKE ? OR Email LIKE ? OR Phone LIKE ?)");
        }
        if (roleFilter != null && !roleFilter.trim().isEmpty()) {
            sql.append(" AND Role = ?");
        }
        
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql.toString());
            int paramIndex = 1;
            
            if (search != null && !search.trim().isEmpty()) {
                String searchPattern = "%" + search + "%";
                pstmt.setString(paramIndex++, searchPattern);
                pstmt.setString(paramIndex++, searchPattern);
                pstmt.setString(paramIndex++, searchPattern);
            }
            if (roleFilter != null && !roleFilter.trim().isEmpty()) {
                pstmt.setString(paramIndex++, roleFilter);
            }
            
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                int count = rs.getInt(1);
                conn.close();
                return count;
            }
            
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return 0;
    }
    
    public boolean createUser(User user) {
        Connection conn = DBConnection.getConnection();
        String sql = "INSERT INTO [User] (Name, Email, Phone, Address, Role, Password, Avatar) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getName());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, user.getPhone());
            pstmt.setString(4, user.getAddress());
            pstmt.setString(5, user.getRole());
            pstmt.setString(6, user.getPassword());
            pstmt.setString(7, user.getAvatar());
            
            int rows = pstmt.executeUpdate();
            conn.close();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public User getUserById(int userId) {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT * FROM [User] WHERE UserID = ?";
        
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("UserID"));
                user.setName(rs.getString("Name"));
                user.setEmail(rs.getString("Email"));
                user.setPhone(rs.getString("Phone"));
                user.setAddress(rs.getString("Address"));
                user.setRole(rs.getString("Role"));
                user.setPassword(rs.getString("Password"));
                user.setAvatar(rs.getString("Avatar"));
                conn.close();
                return user;
            }
            
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    public boolean updateUser(User user) {
        Connection conn = DBConnection.getConnection();
        StringBuilder sql = new StringBuilder("UPDATE [User] SET Name = ?, Email = ?, Phone = ?, Address = ?, Role = ?");
        
        if (user.getPassword() != null && !user.getPassword().trim().isEmpty()) {
            sql.append(", Password = ?");
        }
        
        sql.append(" WHERE UserID = ?");
        
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql.toString());
            int paramIndex = 1;
            
            pstmt.setString(paramIndex++, user.getName());
            pstmt.setString(paramIndex++, user.getEmail());
            pstmt.setString(paramIndex++, user.getPhone());
            pstmt.setString(paramIndex++, user.getAddress());
            pstmt.setString(paramIndex++, user.getRole());
            
            if (user.getPassword() != null && !user.getPassword().trim().isEmpty()) {
                pstmt.setString(paramIndex++, user.getPassword());
            }
            
            pstmt.setInt(paramIndex, user.getUserId());
            
            int rows = pstmt.executeUpdate();
            conn.close();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteUser(int userId) {
        Connection conn = DBConnection.getConnection();
        String sql = "UPDATE [User] SET Status = 0 WHERE UserID = ?";
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            int rows = pstmt.executeUpdate();
            conn.close();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Error in deleteUser: " + e);
            return false;
        }
    }
    
    // Dashboard statistics methods
    public int getTotalUsers() {
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT COUNT(*) FROM [User]";
        
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                int count = rs.getInt(1);
                conn.close();
                return count;
            }
            
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return 0;
    }
    
    public List<User> getRecentUsers(int limit) {
        List<User> users = new ArrayList<>();
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT TOP (?) * FROM [User] ORDER BY UserID DESC";
        
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, limit);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("UserID"));
                user.setName(rs.getString("Name"));
                user.setEmail(rs.getString("Email"));
                user.setPhone(rs.getString("Phone"));
                user.setRole(rs.getString("Role"));
                users.add(user);
            }
            
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return users;
    }
    
    public List<Integer> getMonthlyUserStats() {
        List<Integer> monthlyStats = new ArrayList<>();
        Connection conn = DBConnection.getConnection();
        String sql = "SELECT COUNT(*) as UserCount FROM [User] WHERE YEAR(GETDATE()) = YEAR(GETDATE()) GROUP BY MONTH(GETDATE()) ORDER BY MONTH(GETDATE())";
        
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                monthlyStats.add(rs.getInt("UserCount"));
            }
            
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return monthlyStats;
    }
}
